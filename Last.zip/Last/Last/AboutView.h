//
//  About.h
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;
@interface AboutView : UIView <UIActionSheetDelegate> {
    
    UIPageControl *control;
    ViewController *controller;
    NSInteger numberOfPages;
	NSInteger currentPage;
    UIActionSheet *actionSheet;
  
}

- (id) initWithFrame: (CGRect) f controller: (ViewController *) c;

@end
