//
//  LastAppDelegate.h
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>

@interface LastAppDelegate : NSObject <UIApplicationDelegate> {
    
    SystemSoundID sid;
    
    NSArray *names;
    NSMutableArray *a;
    
    UINavigationController *navigationController;
    
    UIWindow *_window;

}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end
