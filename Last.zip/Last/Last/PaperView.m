//
//  PaperView.m
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PaperView.h"


@implementation PaperView

- (id) initWithFrame: (CGRect) f controller: (ViewController *) c {
{
    self = [super initWithFrame:f];
    if (self) {
        controller = c;
        self.backgroundColor = [UIColor whiteColor];
       
        metal = [NSArray arrayWithObjects:
                 @"Bills",
                 @"Boarding passes",
                 @"Business cards",
                 @"Cardboard boxes",
                 @"Cardboard egg cartons",
                 @"Cardboard tubes",
                 @"Cereal boxes",
                 @"Clasp envelopes",
                 @"Coloring books",
                 @"Comic books",
                 @"Gift wrap",
                 @"Greeting cards",
                 @"Invitations",
                 @"Junk mail",
                 @"Laundry soap boxes",
                 @"Legal pads",
                 @"Looseleaf paper",
                 @"Magazines",
                 @"Mail",
                 @"Newspapers",
                 @"Office paper",
                 @"Paper crafts",
                 @"Paper cups",
                 @"Paper doilies",
                 @"Paper lunch bags",
                 @"Paper shopping bags",
                 @"Paperback books",
                 @"Phonebooks", 
                 @"Pizza boxes",
                 @"Receipts",
                 @"Shoeboxes",
                 @"Shredded paper",
                 @"Sketchbook paper",
                 @"Spiral Notebook paper",
                 @"Stamped envelope",
                 @"Stapled report",
                 @"Statements",
                 @"Stationery",
                 @"Tickets",
                 @"Tissue paper",
                 @"Wall calendars",
                 @"Window envelopes",
                 nil
                 ];
        [metal retain];
        
        tableView = [[UITableView alloc] initWithFrame: f style: UITableViewStylePlain];
        
        tableView.dataSource = self;
        
        //some of the default values inherited from class UIScrollView
        tableView.indicatorStyle = UIScrollViewIndicatorStyleDefault; //scroll bar
        tableView.showsVerticalScrollIndicator = YES;   //fade out when stopped
        tableView.scrollsToTop = YES;                   //click on status bar
        tableView.bounces = YES;  
        
        [self addSubview:tableView];
        
        //pagecontrol
        numberOfPages = 5;
		currentPage = 1;
		
		CGRect b = self.bounds;
		CGSize s = CGSizeMake(16 * numberOfPages, 16);	//size of UIPageControl
		CGRect f = CGRectMake(
                              b.origin.x, 
                              b.origin.y + b.size.height - b.size.height/6, 
                              b.size.width,
                              s.height
                              );
        
		control = [[UIPageControl alloc] initWithFrame: f];
		control.backgroundColor = [UIColor blackColor];
		control.hidesForSinglePage = NO;	//the default
		control.numberOfPages = numberOfPages;
		control.currentPage = currentPage;			//default is 0
		control.userInteractionEnabled = NO;

		[control addTarget: self action: @selector(pageChanged:)
          forControlEvents: UIControlEventTouchUpInside];
        
		[self addSubview: control];
        
    }
    return self;
    }
}

- (void) pageChanged: (id) sender {
	if (sender == control) {
		currentPage = control.currentPage;
	}
}

    
#pragma mark methods of protocol UITableViewDataSource
    
- (NSInteger) numberOfSectionsInTableView: (UITableView *) v {
    return 1;
}

- (NSInteger) tableView: (UITableView *) v numberOfRowsInSection: (NSInteger) section {
    
    return metal.count;
}

- (UITableViewCell *) tableView: (UITableView *) v cellForRowAtIndexPath: (NSIndexPath *) indexPath {
    
    static NSString *identifier = @"metal";
    UITableViewCell *cell =
    [tableView dequeueReusableCellWithIdentifier: identifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc]
                initWithStyle: UITableViewCellStyleDefault
                reuseIdentifier: identifier
                ];
        [cell autorelease];
    } 
    
    cell.textLabel.text = [metal objectAtIndex: indexPath.row];
    //NSString *fileName = [cell.textLabel.text stringByAppendingString: @".png"];
    //cell.imageView.image = [UIImage imageNamed: fileName]; //nil if .jpg file doesn't exist
    return cell;
}



    
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)dealloc
{
    [tableView release];
    [metal release];
    [controller release];
    [control release];
    [super dealloc];
}

@end
