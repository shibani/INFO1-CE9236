//
//  TrashView.h
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ViewController;
@interface TrashView : UIView <UITableViewDataSource> {
    
    UIPageControl *control;
    ViewController *controller;
    NSArray *trash;
    UITableView *tableView;
    NSInteger numberOfPages;
	NSInteger currentPage;
}

- (id) initWithFrame: (CGRect) f controller: (ViewController *) c;

@end
