//
//  LastAppDelegate.m
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LastAppDelegate.h"
#import "ViewController.h"

@implementation LastAppDelegate
@synthesize window=_window;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    names = [NSArray arrayWithObjects:
             @"Home",
             @"Paper",
             @"Glass-Metal-Plastic",
             @"Trash",
             @"About",
             nil
             ];
	[names retain];
    
	UIScreen *s = [UIScreen mainScreen];
    
    a = [[NSMutableArray alloc] init];
    
	[a addObject: [[ViewController alloc]
                   initWithTitle: [names objectAtIndex: 0]
                             ]];

    
    navigationController = [[UINavigationController alloc] initWithRootViewController: [a objectAtIndex: 0]];
    _window = [[UIWindow alloc] initWithFrame: s.bounds];
    
    [self.window addSubview: navigationController.view];
    [self.window makeKeyAndVisible];
    
    NSBundle *bundle = [NSBundle mainBundle];
	NSLog(@"bundle.bundlePath == \"%@\"", bundle.bundlePath);	
	
	NSString *filename = [bundle
                          pathForResource: @"Electric Flutters"
                          ofType: @"caf"
                          ];
	NSLog(@"filename == \"%@\"", filename);
	
	NSURL *url = [NSURL fileURLWithPath: filename isDirectory: NO];
	NSLog(@"url == \"%@\"", url);
    
    OSStatus error =
    AudioServicesCreateSystemSoundID((CFURLRef)url, &sid);
    
	if (error != kAudioServicesNoError) {
		NSLog(@"AudioServicesCreateSystemSoundID error == %ld", error);
	}

    return YES;
}

- (void) nextView {
    
	NSUInteger i = navigationController.viewControllers.count;
	if (i == names.count) {
		//All the station are already pushed.
		return;
	}
	
	if (a.count <= i) {
        
		//This station is being pushed for the first time.
		[a addObject: [[ViewController alloc]
                       initWithTitle: [names objectAtIndex: i]
                       ]];
	}
	
	[navigationController pushViewController: [a objectAtIndex: i] animated: YES];
}

- (void) playSound {

        AudioServicesPlaySystemSound(sid);
}


- (void)applicationWillResignActive:(UIApplication *)application
{
    /*
     Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
     Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
     */
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    /*
     Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
     If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
     */
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    /*
     Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
     */
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    /*
     Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
     */
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    /*
     Called when the application is about to terminate.
     Save data if appropriate.
     See also applicationDidEnterBackground:.
     */
}

#pragma mark - Memory management

- (void)applicationDidReceiveMemoryWarning:(UIApplication *)application {
    
}

- (void)dealloc
{
    for (ViewController *c in a) {
		[c release];
	}
    [_window release];
    [navigationController release];
    [a release];
    [names release];
    [super dealloc];
}

@end
