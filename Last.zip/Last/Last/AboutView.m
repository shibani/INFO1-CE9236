//
//  About.m
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "AboutView.h"


@implementation AboutView

enum {
    actionHarmful,
    actionTakeItBack,
    actionReuseIt,
    actionCompost,
    actionCancel
};


- (id) initWithFrame: (CGRect) f controller: (ViewController *) c 
{
    self = [super initWithFrame:f];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        
    
        //Disposal guidelines http://www.nyc.gov/html/nycwasteless/html/stuff/disposal_residents.shtml
        
        
        //pagecontrol
        numberOfPages = 5;
		currentPage = 4;
		
		CGRect b = self.bounds;
		CGSize s = CGSizeMake(16 * numberOfPages, 16);	//size of UIPageControl
		CGRect f = CGRectMake(
                              b.origin.x, 
                              b.origin.y + b.size.height - b.size.height/6, 
                              b.size.width,
                              s.height
                              );
        
		control = [[UIPageControl alloc] initWithFrame: f];
		control.backgroundColor = [UIColor blackColor];
		control.hidesForSinglePage = NO;	//the default
		control.numberOfPages = numberOfPages;
		control.currentPage = currentPage;			//default is 0
        control.userInteractionEnabled = NO;
		
		[control addTarget: self action: @selector(pageChanged:)
          forControlEvents: UIControlEventTouchUpInside];
        
		[self addSubview: control];

    }
    return self;
}

- (void) pageChanged: (id) sender {
	if (sender == control) {
		currentPage = control.currentPage;
	}
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
    
     if (touches.count < 2) {
        
        [self performSelector: @selector(showActionSheet) withObject: nil];
    } 
}

- (void) showActionSheet {
	
	actionSheet = [[UIActionSheet alloc]
                   initWithTitle: @"For more Information on:"
                   delegate: self
                   cancelButtonTitle: @"Cancel"
                   destructiveButtonTitle: @"Harmful Household Products"
                   otherButtonTitles:
                   @"Take it Back NYC",
                   @"Reuse it",
                   @"Compost",
                   nil
                   ];
	
	[actionSheet showInView: self];
}

#pragma mark - Method of protocol UIActionSheetDelegate

- (void) actionSheet: (UIActionSheet *) a clickedButtonAtIndex: (NSInteger) buttonIndex {
	
	if (a == actionSheet) {
		switch (buttonIndex) {
			case actionHarmful: {
                NSURL *url = [NSURL URLWithString:  
                              @"http://www.nyc.gov/html/nycwasteless/html/stuff/harmful_hh_prod.shtml"
                              ];
                UIApplication *app = [UIApplication sharedApplication];
				if (![app canOpenURL: url]) {
					NSLog(@"Can't open url %@.", url);
					break;
				}
				if (![app openURL: url]) {
					NSLog(@"failed to open URL %@", url);
				}
            }
				break;
				
			case actionTakeItBack: {
				NSURL *url = [NSURL URLWithString:
                              @"http://www.nyc.gov/html/nycwasteless/html/stuff/takeback.shtml"
                              ];
                UIApplication *app = [UIApplication sharedApplication];
				if (![app canOpenURL: url]) {
					NSLog(@"Can't open url %@.", url);
					break;
				}
				if (![app openURL: url]) {
					NSLog(@"failed to open URL %@", url);
				}
				break;
			}
				
			case actionReuseIt: {
                NSURL *url = [NSURL URLWithString:
                              @"http://www.nyc.gov/html/nycwasteless/html/stuff/reuse_residents.shtml"
                              ];
                UIApplication *app = [UIApplication sharedApplication];
				if (![app canOpenURL: url]) {
					NSLog(@"Can't open url %@.", url);
					break;
				}
				if (![app openURL: url]) {
					NSLog(@"failed to open URL %@", url);
				}
                break;
				
            }   
			case actionCompost: {
                NSURL *url = [NSURL URLWithString:
                              @"http://www.nyc.gov/html/nycwasteless/html/compost/composting_nyc.shtml"
                              ];
                UIApplication *app = [UIApplication sharedApplication];
				if (![app canOpenURL: url]) {
					NSLog(@"Can't open url %@.", url);
					break;
				}
				if (![app openURL: url]) {
					NSLog(@"failed to open URL %@", url);
				}
                break;
            }
		}
	}
}

- (void)drawRect:(CGRect)rect
{
    
  NSString *about = @"The NYC Department of Sanitation's Bureau of Waste Prevention, Reuse and Recycling (BWPRR) plans, implements, and evaluates the Department's recycling, composting, and waste prevention programs.\n\nSUMMARY OF BWPRR PROGRAMS:\n• Recycling and waste prevention\n• Composting\n• Reuse Programs\n• Take it back, NYC & Special Waste\n\nCONTACT:\nIf you have questions, you may call\nthe NYC Citizen Service Center\nat 3-1-1.\n\nOR, WRITE TO:\nNYC Department of Sanitation\nCentral Correspondence Unit\n346 Broadway, 10th Floor\nNew York, NY 10013.";  
    
    UIFont *f = [UIFont systemFontOfSize: 12];
    
    CGRect r = CGRectMake(10, 10, self.bounds.size.width - 10, self.bounds.size.height - 10);
    
    [about drawInRect:r withFont:f];
    
    UIImage *aboutLogo = [UIImage imageNamed: @"aboutlogo.png"];
    UIImageView *aboutLogoView = [[UIImageView alloc] initWithImage: aboutLogo];
    aboutLogoView.center = CGPointMake(self.bounds.size.width * 5/6, self.bounds.size.height * 8/12);
    [self addSubview: aboutLogoView];
    [aboutLogoView release];
}


- (void)dealloc
{
    [actionSheet release];
    [control release];
    [super dealloc];
}

@end
