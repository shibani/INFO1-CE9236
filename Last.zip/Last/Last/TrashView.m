//
//  TrashView.m
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TrashView.h"


@implementation TrashView

- (id) initWithFrame: (CGRect) f controller: (ViewController *) c
{
    self = [super initWithFrame:f];
    if (self) {
        controller = c;
        self.backgroundColor = [UIColor whiteColor];
        
        trash = [NSArray arrayWithObjects:
                 @"Alkaline batteries",
                 @"Apple core",
                 @"Avocado",
                 @"Bagel",
                 @"Banana peel",
                 @"Battery charger",
                 @"Blanket",
                 @"Book (hardcover)",
                 @"Bubblewrap",
                 @"Camera (disposable)",
                 @"Candy wrapper",
                 @"Car Seat (damaged)",
                 @"Carrot",
                 @"CD case",
                 @"Cell phone",
                 @"Ceramic bowl (chipped)",
                 @"Ceramic cup (chipped)",
                 @"Cheese",
                 @"Cherries",
                 @"Chewing gum wrapper",
                 @"Chicken",
                 @"Chinese takeout box",
                 @"Christmas Tree",
                 @"Clamshell container",
                 @"Computer monitor",
                 @"Computer tower",
                 @"Cosmetics",
                 @"Couch", 
                 @"Croissant",
                 @"Eggshells",
                 @"Flowers",
                 @"Flourescent tubelights",
                 @"Foam cooler",
                 @"Foam cup",
                 @"Foam packing peanuts",
                 @"Fries",
                 @"Graden trimmings",
                 @"Glassware",
                 @"Grapes",
                 @"Grass clippings",
                 @"Hand mirror",
                 @"Hot Dog",
                 @"Ice cream cone",
                 @"Jacket",
                 @"Laptop",
                 @"Lemons",
                 @"Lettuce",
                 @"Light bulb (flourescent)",
                 @"Light bulb (incandescent)",
                 @"Lobster shells",
                 @"Mattress",
                 @"Mirror",
                 @"Mouse trap",
                 @"Mp3 player",
                 @"Muffin",
                 @"Office chair",
                 @"Oil filter",
                 @"Orange",
                 @"Packet (hot chocolate)",
                 @"Packet (oatmeal)",
                 @"Pants",
                 @"Papaya",
                 @"Paper napkin",
                 @"Paper plate (used)",
                 @"Paper towels",
                 @"Pear",
                 @"Pineapple",
                 @"Pizza",
                 @"Plastic bag",
                 @"Plastic bucket",
                 @"Plastic cup",
                 @"Plastic deli container",
                 @"Plastic deli container lid",
                 @"Plastic dish rack",
                 @"Plastic fork",
                 @"Plastic hanger",
                 @"Plastic knife",
                 @"Plastic laundry tote",
                 @"Plastic patio chair",
                 @"Plastic pipe",
                 @"Plastic rings (six pack)",
                 @"Plastic salad container",
                 @"Plastic spoon",
                 @"Plastic toy",
                 @"Plastic wrap",
                 @"Popsicle stick",
                 @"Pretzel",
                 @"Printer",
                 @"Rug",
                 @"Sauce packet",
                 @"Shirt",
                 @"Shirt (tattered)",
                 @"Sneakers",
                 @"Sponge",
                 @"Steak",
                 @"Straw",
                 @"Styrofoam container",
                 @"Syringe",
                 @"Totebag",
                 @"Television",
                 @"Toner cartridge",
                 @"Towel",
                 @"Vacuum cleaner",
                 @"VHS tape",
                 @"Waffles",
                 @"Watermelon",
                 @"Wood hanger",
                 @"Yogurt container",
                 nil
                 ];
        [trash retain];
        
        tableView = [[UITableView alloc] initWithFrame: f style: UITableViewStylePlain];
        
        tableView.dataSource = self;
        
        //some of the default values inherited from class UIScrollView
        tableView.indicatorStyle = UIScrollViewIndicatorStyleDefault; //scroll bar
        tableView.showsVerticalScrollIndicator = YES;   //fade out when stopped
        tableView.scrollsToTop = YES;                   //click on status bar
        tableView.bounces = YES;  
        
        [self addSubview:tableView];
    
        //pagecontrol
        numberOfPages = 5;
		currentPage = 3;
		
		CGRect b = self.bounds;
		CGSize s = CGSizeMake(16 * numberOfPages, 16);	//size of UIPageControl
		CGRect f = CGRectMake(
                              b.origin.x, 
                              b.origin.y + b.size.height - b.size.height/6, 
                              b.size.width,
                              s.height
                              );
        
		control = [[UIPageControl alloc] initWithFrame: f];
		control.backgroundColor = [UIColor blackColor];
		control.hidesForSinglePage = NO;	//the default
		control.numberOfPages = numberOfPages;
		control.currentPage = currentPage;			//default is 0
		control.userInteractionEnabled = NO;

		[control addTarget: self action: @selector(pageChanged:)
          forControlEvents: UIControlEventTouchUpInside];
        
		[self addSubview: control];

    }
    return self;
}

- (void) pageChanged: (id) sender {
	if (sender == control) {
		currentPage = control.currentPage;
	}
}

#pragma mark methods of protocol UITableViewDataSource

- (NSInteger) numberOfSectionsInTableView: (UITableView *) v {
    return 1;
}

- (NSInteger) tableView: (UITableView *) v numberOfRowsInSection: (NSInteger) section {
    
    return trash.count;
}

- (UITableViewCell *) tableView: (UITableView *) v cellForRowAtIndexPath: (NSIndexPath *) indexPath {
    
    static NSString *identifier = @"trash";
    UITableViewCell *cell =
    [tableView dequeueReusableCellWithIdentifier: identifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc]
                initWithStyle: UITableViewCellStyleDefault
                reuseIdentifier: identifier
                ];
        [cell autorelease];
    }
    
    cell.textLabel.text = [trash objectAtIndex: indexPath.row];
    return cell;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)dealloc
{
    [tableView release];
    [trash release];
    [controller release];
    [control release];
    [super dealloc];
}

@end
