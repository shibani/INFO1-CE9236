//
//  GlassView.m
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "GlassView.h"


@implementation GlassView

- (id) initWithFrame: (CGRect) f controller: (ViewController *) c
{
    self = [super initWithFrame:f];
    if (self) {
            controller = c;
            self.backgroundColor = [UIColor whiteColor];
            
            glass = [NSArray arrayWithObjects:
                     @"Aerosol cans",
                     @"Aluminum foil",
                     @"Aluminum trays",
                     @"Aluminum water bottles",
                     @"Beer bottles",
                     @"Brass horns",
                     @"Coffee cans",
                     @"Detergent bottles",
                     @"Dish soap bottles",
                     @"Doorknobs",
                     @"Energy drink bottles",
                     @"Fruit juice bottles",
                     @"Glass jars",
                     @"Hammers",
                     @"Iced tea bottles",
                     @"Irons",
                     @"Juice boxes",
                     @"Lawnmowers",
                     @"Lotion bottles",
                     @"Metal bottle caps",
                     @"Metal buckets",
                     @"Metal cans",
                     @"Metal chairs",
                     @"Metal filing cabinets",
                     @"Metal hangers",
                     @"Metal lamps",
                     @"Metal locks",
                     @"Metal pipe", 
                     @"Metal scissors (broken)",
                     @"Metal shelving",
                     @"Metal travel mug",
                     @"Milk carton",
                     @"Milk jug",
                     @"Mustard bottle",
                     @"Nuts & bolts",
                     @"Pie tin",
                     @"Plastic cleaning jug",
                     @"Plastic gallon jug",
                     @"Sauce can",
                     @"Saucepan",
                     @"Shampoo bottle",
                     @"Soda bottle",
                     @"Soda can",
                     @"Soft-sided bottle",
                     @"Spray bottle",
                     @"Spray cleaner bottles",
                     @"Stove",
                     @"Toaster",
                     @"Water bottle",
                     @"Window (metal frame)",
                     @"Wine bottle",
                     nil
                     ];
            [glass retain];
            
            tableView = [[UITableView alloc] initWithFrame: f style: UITableViewStylePlain];
            
            tableView.dataSource = self;
            
            //some of the default values inherited from class UIScrollView
            tableView.indicatorStyle = UIScrollViewIndicatorStyleDefault; //scroll bar
            tableView.showsVerticalScrollIndicator = YES;   //fade out when stopped
            tableView.scrollsToTop = YES;                   //click on status bar
            tableView.bounces = YES;  
            
            [self addSubview:tableView];
        
        //pagecontrol
        numberOfPages = 5;
		currentPage = 2;
		
		CGRect b = self.bounds;
		CGSize s = CGSizeMake(16 * numberOfPages, 16);	//size of UIPageControl
		CGRect f = CGRectMake(
                              b.origin.x, 
                              b.origin.y + b.size.height - b.size.height/6, 
                              b.size.width,
                              s.height
                              );
        
		control = [[UIPageControl alloc] initWithFrame: f];
		control.backgroundColor = [UIColor blackColor];
		control.hidesForSinglePage = NO;	//the default
		control.numberOfPages = numberOfPages;
		control.currentPage = currentPage;			//default is 0
		control.userInteractionEnabled = NO;

        
		[control addTarget: self action: @selector(pageChanged:)
          forControlEvents: UIControlEventTouchUpInside];
        
		[self addSubview: control];
        
       
    }
    return self;
}

- (void) pageChanged: (id) sender {
	if (sender == control) {
		currentPage = control.currentPage;
	}
}

#pragma mark methods of protocol UITableViewDataSource

- (NSInteger) numberOfSectionsInTableView: (UITableView *) v {
    return 1;
}

- (NSInteger) tableView: (UITableView *) v numberOfRowsInSection: (NSInteger) section {
    
    return glass.count;
}

- (UITableViewCell *) tableView: (UITableView *) v cellForRowAtIndexPath: (NSIndexPath *) indexPath {
    
    static NSString *identifier = @"glass";
    UITableViewCell *cell =
    [tableView dequeueReusableCellWithIdentifier: identifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc]
                initWithStyle: UITableViewCellStyleDefault
                reuseIdentifier: identifier
                ];
        [cell autorelease];
    } 
    
    cell.textLabel.text = [glass objectAtIndex: indexPath.row];
    return cell;
}



/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

- (void)dealloc
{
    [tableView release];
    [glass release];
    [controller release];
    [control release];
    [super dealloc];
}

@end
