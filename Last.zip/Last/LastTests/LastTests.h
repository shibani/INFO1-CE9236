//
//  LastTests.h
//  LastTests
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface LastTests : SenTestCase {
@private
    
}

@end
