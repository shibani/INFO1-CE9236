//
//  ViewController.h
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ViewController : UIViewController {
    
    
}

- (id) initWithTitle: (NSString *) title;
- (void) nextView;

@end
