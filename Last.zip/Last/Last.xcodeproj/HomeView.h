//
//  HomeView.h
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@class ViewController;
@interface HomeView : UIView {
    
    ViewController *controller;
    UIPageControl *control;
	NSInteger numberOfPages;
	NSInteger currentPage;
    UIImageView *title1View;
    UIImageView *title2View;


}

- (id) initWithFrame: (CGRect) f controller: (ViewController *) c;
- (void) pageChanged: (id) sender;

@end
