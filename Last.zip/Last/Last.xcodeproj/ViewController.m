//
//  ViewController.m
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "LastAppDelegate.h"
#import "ViewController.h"
#import "HomeView.h"
#import "PaperView.h"
#import "GlassView.h"
#import "TrashView.h"
#import "AboutView.h"

@implementation ViewController

- (id) initWithTitle: (NSString *) title {
    
    self = [super initWithNibName:nil bundle:nil];
    if (self != nil) {
		// Custom initialization
		self.title = title;
        
        self.navigationItem.rightBarButtonItem = 
        [[UIBarButtonItem alloc] initWithTitle: @"Next"
                                         style: UIBarButtonItemStylePlain
                                        target: self
                                        action: @selector(nextView)
         ];
    }
    return self;
}

- (void) nextView {
    
    UIApplication *a = [UIApplication sharedApplication];
	LastAppDelegate *d = a.delegate;
	[d nextView];
}


#pragma mark - View lifecycle

- (void)loadView
{
    CGRect f = [UIScreen mainScreen].bounds;
    
    if (self.title == @"Home") {
    self.view = [[HomeView alloc]initWithFrame:f controller: self];
    } else if (self.title == @"Paper") {
        self.view = [[PaperView alloc]initWithFrame:f controller: self];
    } else if (self.title == @"Glass-Metal-Plastic") {        
        self.view = [[GlassView alloc]initWithFrame:f controller: self];        
    } else if (self.title == @"Trash") {
        self.view = [[TrashView alloc]initWithFrame:f controller: self];
    } else if (self.title == @"About") {
        self.view = [[AboutView alloc]initWithFrame:f controller: self];
        self.navigationItem.rightBarButtonItem = nil;
    }
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
/*
- (void)viewDidLoad
{
    [super viewDidLoad];
}
*/

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Memory management

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)dealloc
{
    [self.view release];
    [super dealloc];
}

@end
