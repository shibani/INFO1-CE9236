//
//  HomeView.m
//  Last
//
//  Created by Shibani Mookerjee on 8/9/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HomeView.h"
#import "ViewController.h"
#import "PaperView.h"

@implementation HomeView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}

- (id) initWithFrame: (CGRect) f controller: (ViewController *) c {
    
    self = [super initWithFrame:f];
    if (self) {
        
        controller = c;
        self.backgroundColor = [UIColor colorWithRed: 0.99
                                               green: 0.945
                                                blue: 0.77
                                               alpha: 1.0];
        
        UIImage *image2 = [UIImage imageNamed: @"RECYCLE.jpg"];
        UIImage *logo = [UIImage imageNamed: @"logo.png"];

        UIImageView *imageView2 = [[UIImageView alloc] initWithImage: image2];
        imageView2.center = CGPointMake(self.bounds.size.width/2, self.bounds.size.height * 5/12);
        [self addSubview: imageView2];
        [imageView2 release];
        
        UIImage *title1 = [UIImage imageNamed: @"title1.png"]; 
        title1View = [[UIImageView alloc] initWithImage: title1];
        title1View.center = CGPointMake(-self.bounds.size.width/2, -self.bounds.size.height/2);
        [self addSubview: title1View];
        
        
        UIImage *title2 = [UIImage imageNamed: @"title2.png"]; 
        title2View = [[UIImageView alloc] initWithImage: title2];
        title2View.center = CGPointMake(self.bounds.size.width + self.bounds.size.width/2, -self.bounds.size.height/2);
        [self addSubview: title2View];
        
        
        UIImageView *logoView = [[UIImageView alloc] initWithImage: logo];
        logoView.center = CGPointMake(self.bounds.size.width * 5/6, self.bounds.size.height * 3/4);
        [self addSubview: logoView];
        [logoView release];

        
        numberOfPages = 5;
		currentPage = 0;
		
		CGRect b = self.bounds;
		CGSize s = CGSizeMake(16 * numberOfPages, 16);	//size of UIPageControl
		CGRect f = CGRectMake(
                              b.origin.x, 
                              b.origin.y + b.size.height - b.size.height/6, 
                              b.size.width,
                              s.height
                              );
        
		control = [[UIPageControl alloc] initWithFrame: f];
		control.backgroundColor = [UIColor blackColor];
		control.hidesForSinglePage = NO;	//the default
		control.numberOfPages = numberOfPages;
		control.currentPage = currentPage;			//default is 0
		control.userInteractionEnabled = NO;

        
		[control addTarget: self action: @selector(pageChanged:)
          forControlEvents: UIControlEventTouchUpInside];
        
		[self addSubview: control];
        
        [NSTimer scheduledTimerWithTimeInterval: 1.5
                                         target: self
                                       selector: @selector(playSound:)
                                       userInfo: nil
                                        repeats: NO
         ];
        
        [NSTimer scheduledTimerWithTimeInterval: 3.5
                                         target: self
                                       selector: @selector(playSound:)
                                       userInfo: nil
                                        repeats: NO
         ];
    }   return self;
    }   

- (void) pageChanged: (id) sender {
	if (sender == control) {
		currentPage = control.currentPage;
        }
}

- (void) drawRect: (CGRect) rect {
    
    UIImage *title1 = [UIImage imageNamed: @"title1.png"]; 
    CGSize title1Size = title1.size;
    UIImage *title2 = [UIImage imageNamed: @"title2.png"]; 
    CGSize title2Size = title2.size;

    
    [UIView animateWithDuration: 2.0 
                          delay: 0
                        options: UIViewAnimationOptionCurveEaseIn
                     animations: ^{
                         
                         
                         title1View.center = CGPointMake(self.bounds.size.width/2 - title1Size.width/2 - 15,            
                                                         self.bounds.size.height/7
                                                     );
                         
                     }
                     completion: nil    ]; 
    
    [UIView animateWithDuration: 2.0 
                          delay: 2.0
                        options: UIViewAnimationOptionCurveEaseIn
                     animations: ^{
                         
                         
                         title2View.center = CGPointMake(
                                                         self.bounds.size.width/2 + title2Size.width/2 - 15,
                                                         self.bounds.size.height/7
                                                         );
                         
                     }
                     completion: nil    ];
}

-(void) playSound: (NSTimer *) t {
    [t invalidate];
    [[UIApplication sharedApplication].delegate playSound];
    
}

- (void) dealloc {
    [title2View release];
    [title1View release];
    [control release];
    [controller release];
    [super dealloc];
}

@end